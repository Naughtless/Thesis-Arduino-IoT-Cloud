<?php

const DB_HOST = "tt-dbs.c3krwjdn440p.ap-southeast-1.rds.amazonaws.com";
const DB_PORT = "3306";
const DB_USERNAME = "admin";
const DB_PASSWORD = "administrator";
const DB_SCHEMA = "thesis-rds";